let obj = {
    "Invalid_Record": "Invalid Record",
    "Password_Not_Match": "Password Not Match",
    login_success: "Login success"
}

module.exports = obj;       