const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://vakeelsingh000:RVrcAyXTrc2pGlMk@cluster0.raieoxa.mongodb.net/?retryWrites=true&w=majority");
module.exports = mongoose;  